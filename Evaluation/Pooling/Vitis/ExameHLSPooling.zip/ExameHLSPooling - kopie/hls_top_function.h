#ifndef HLS_TOP_FUNCTION_H
#define HLS_TOP_FUNCTION_H

void max_pooling(unsigned char* image, unsigned char* pooled_image, int width, int height, int channels, int pool_size);

void min_pooling(unsigned char* image, unsigned char* pooled_image, int width, int height, int channels, int pool_size);

#endif
