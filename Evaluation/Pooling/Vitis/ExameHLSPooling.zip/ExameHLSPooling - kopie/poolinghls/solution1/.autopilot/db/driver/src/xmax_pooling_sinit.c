// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.2 (64-bit)
// Tool Version Limit: 2023.10
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xmax_pooling.h"

extern XMax_pooling_Config XMax_pooling_ConfigTable[];

#ifdef SDT
XMax_pooling_Config *XMax_pooling_LookupConfig(UINTPTR BaseAddress) {
	XMax_pooling_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XMax_pooling_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XMax_pooling_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XMax_pooling_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XMax_pooling_Initialize(XMax_pooling *InstancePtr, UINTPTR BaseAddress) {
	XMax_pooling_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XMax_pooling_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XMax_pooling_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XMax_pooling_Config *XMax_pooling_LookupConfig(u16 DeviceId) {
	XMax_pooling_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XMAX_POOLING_NUM_INSTANCES; Index++) {
		if (XMax_pooling_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XMax_pooling_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XMax_pooling_Initialize(XMax_pooling *InstancePtr, u16 DeviceId) {
	XMax_pooling_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XMax_pooling_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XMax_pooling_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

