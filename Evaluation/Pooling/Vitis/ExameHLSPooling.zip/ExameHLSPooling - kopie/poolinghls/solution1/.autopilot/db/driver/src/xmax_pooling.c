// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.2 (64-bit)
// Tool Version Limit: 2023.10
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xmax_pooling.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XMax_pooling_CfgInitialize(XMax_pooling *InstancePtr, XMax_pooling_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XMax_pooling_Start(XMax_pooling *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMax_pooling_ReadReg(InstancePtr->Control_BaseAddress, XMAX_POOLING_CONTROL_ADDR_AP_CTRL) & 0x80;
    XMax_pooling_WriteReg(InstancePtr->Control_BaseAddress, XMAX_POOLING_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XMax_pooling_IsDone(XMax_pooling *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMax_pooling_ReadReg(InstancePtr->Control_BaseAddress, XMAX_POOLING_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XMax_pooling_IsIdle(XMax_pooling *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMax_pooling_ReadReg(InstancePtr->Control_BaseAddress, XMAX_POOLING_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XMax_pooling_IsReady(XMax_pooling *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMax_pooling_ReadReg(InstancePtr->Control_BaseAddress, XMAX_POOLING_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XMax_pooling_EnableAutoRestart(XMax_pooling *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMax_pooling_WriteReg(InstancePtr->Control_BaseAddress, XMAX_POOLING_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XMax_pooling_DisableAutoRestart(XMax_pooling *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMax_pooling_WriteReg(InstancePtr->Control_BaseAddress, XMAX_POOLING_CONTROL_ADDR_AP_CTRL, 0);
}

void XMax_pooling_Set_image_r(XMax_pooling *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMax_pooling_WriteReg(InstancePtr->Control_BaseAddress, XMAX_POOLING_CONTROL_ADDR_IMAGE_R_DATA, (u32)(Data));
    XMax_pooling_WriteReg(InstancePtr->Control_BaseAddress, XMAX_POOLING_CONTROL_ADDR_IMAGE_R_DATA + 4, (u32)(Data >> 32));
}

u64 XMax_pooling_Get_image_r(XMax_pooling *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMax_pooling_ReadReg(InstancePtr->Control_BaseAddress, XMAX_POOLING_CONTROL_ADDR_IMAGE_R_DATA);
    Data += (u64)XMax_pooling_ReadReg(InstancePtr->Control_BaseAddress, XMAX_POOLING_CONTROL_ADDR_IMAGE_R_DATA + 4) << 32;
    return Data;
}

void XMax_pooling_Set_pooled_image(XMax_pooling *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMax_pooling_WriteReg(InstancePtr->Control_BaseAddress, XMAX_POOLING_CONTROL_ADDR_POOLED_IMAGE_DATA, (u32)(Data));
    XMax_pooling_WriteReg(InstancePtr->Control_BaseAddress, XMAX_POOLING_CONTROL_ADDR_POOLED_IMAGE_DATA + 4, (u32)(Data >> 32));
}

u64 XMax_pooling_Get_pooled_image(XMax_pooling *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMax_pooling_ReadReg(InstancePtr->Control_BaseAddress, XMAX_POOLING_CONTROL_ADDR_POOLED_IMAGE_DATA);
    Data += (u64)XMax_pooling_ReadReg(InstancePtr->Control_BaseAddress, XMAX_POOLING_CONTROL_ADDR_POOLED_IMAGE_DATA + 4) << 32;
    return Data;
}

void XMax_pooling_Set_width(XMax_pooling *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMax_pooling_WriteReg(InstancePtr->Control_BaseAddress, XMAX_POOLING_CONTROL_ADDR_WIDTH_DATA, Data);
}

u32 XMax_pooling_Get_width(XMax_pooling *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMax_pooling_ReadReg(InstancePtr->Control_BaseAddress, XMAX_POOLING_CONTROL_ADDR_WIDTH_DATA);
    return Data;
}

void XMax_pooling_Set_height(XMax_pooling *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMax_pooling_WriteReg(InstancePtr->Control_BaseAddress, XMAX_POOLING_CONTROL_ADDR_HEIGHT_DATA, Data);
}

u32 XMax_pooling_Get_height(XMax_pooling *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMax_pooling_ReadReg(InstancePtr->Control_BaseAddress, XMAX_POOLING_CONTROL_ADDR_HEIGHT_DATA);
    return Data;
}

void XMax_pooling_Set_channels(XMax_pooling *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMax_pooling_WriteReg(InstancePtr->Control_BaseAddress, XMAX_POOLING_CONTROL_ADDR_CHANNELS_DATA, Data);
}

u32 XMax_pooling_Get_channels(XMax_pooling *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMax_pooling_ReadReg(InstancePtr->Control_BaseAddress, XMAX_POOLING_CONTROL_ADDR_CHANNELS_DATA);
    return Data;
}

void XMax_pooling_Set_pool_size(XMax_pooling *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMax_pooling_WriteReg(InstancePtr->Control_BaseAddress, XMAX_POOLING_CONTROL_ADDR_POOL_SIZE_DATA, Data);
}

u32 XMax_pooling_Get_pool_size(XMax_pooling *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMax_pooling_ReadReg(InstancePtr->Control_BaseAddress, XMAX_POOLING_CONTROL_ADDR_POOL_SIZE_DATA);
    return Data;
}

void XMax_pooling_InterruptGlobalEnable(XMax_pooling *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMax_pooling_WriteReg(InstancePtr->Control_BaseAddress, XMAX_POOLING_CONTROL_ADDR_GIE, 1);
}

void XMax_pooling_InterruptGlobalDisable(XMax_pooling *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMax_pooling_WriteReg(InstancePtr->Control_BaseAddress, XMAX_POOLING_CONTROL_ADDR_GIE, 0);
}

void XMax_pooling_InterruptEnable(XMax_pooling *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMax_pooling_ReadReg(InstancePtr->Control_BaseAddress, XMAX_POOLING_CONTROL_ADDR_IER);
    XMax_pooling_WriteReg(InstancePtr->Control_BaseAddress, XMAX_POOLING_CONTROL_ADDR_IER, Register | Mask);
}

void XMax_pooling_InterruptDisable(XMax_pooling *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMax_pooling_ReadReg(InstancePtr->Control_BaseAddress, XMAX_POOLING_CONTROL_ADDR_IER);
    XMax_pooling_WriteReg(InstancePtr->Control_BaseAddress, XMAX_POOLING_CONTROL_ADDR_IER, Register & (~Mask));
}

void XMax_pooling_InterruptClear(XMax_pooling *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMax_pooling_WriteReg(InstancePtr->Control_BaseAddress, XMAX_POOLING_CONTROL_ADDR_ISR, Mask);
}

u32 XMax_pooling_InterruptGetEnabled(XMax_pooling *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMax_pooling_ReadReg(InstancePtr->Control_BaseAddress, XMAX_POOLING_CONTROL_ADDR_IER);
}

u32 XMax_pooling_InterruptGetStatus(XMax_pooling *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMax_pooling_ReadReg(InstancePtr->Control_BaseAddress, XMAX_POOLING_CONTROL_ADDR_ISR);
}

