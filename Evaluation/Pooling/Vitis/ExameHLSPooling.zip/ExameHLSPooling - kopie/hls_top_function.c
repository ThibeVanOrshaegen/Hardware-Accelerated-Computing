#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void max_pooling(unsigned char* image, unsigned char* pooled_image, int width, int height, int channels, int pool_size) {
#pragma HLS INTERFACE s_axilite port=return bundle=control
#pragma HLS INTERFACE s_axilite port=image bundle=control
#pragma HLS INTERFACE s_axilite port=pooled_image bundle=control
#pragma HLS INTERFACE s_axilite port=width bundle=control
#pragma HLS INTERFACE s_axilite port=height bundle=control
#pragma HLS INTERFACE s_axilite port=channels bundle=control
#pragma HLS INTERFACE s_axilite port=pool_size bundle=control
#pragma HLS INTERFACE m_axi depth=65536 port=image offset=slave bundle=input //gmem
#pragma HLS INTERFACE m_axi depth=65536 port=pooled_image offset=slave bundle=output //gmem
#pragma HLS PIPELINE

    int pooled_width = width / pool_size;
    int pooled_height = height / pool_size;

    for (int c = 0; c < channels; ++c) {
        for (int i = 0; i < pooled_height; ++i) {
            for (int j = 0; j < pooled_width; ++j) {
                unsigned char max_val = 0;
                for (int m = 0; m < pool_size; ++m) {
                    for (int n = 0; n < pool_size; ++n) {
#pragma HLS UNROLL
                        int index = ((i * pool_size + m) * width + (j * pool_size + n)) * channels + c;
                        if (image[index] > max_val) {
                            max_val = image[index];
                        }
                    }
                }
                int pooled_index = (i * pooled_width + j) * channels + c;
                pooled_image[pooled_index] = max_val;
            }
        }
    }
}

void min_pooling(unsigned char* image, unsigned char* pooled_image, int width, int height, int channels, int pool_size) {
#pragma HLS INTERFACE s_axilite port=return bundle=control
#pragma HLS INTERFACE s_axilite port=image bundle=control
#pragma HLS INTERFACE s_axilite port=pooled_image bundle=control
#pragma HLS INTERFACE s_axilite port=width bundle=control
#pragma HLS INTERFACE s_axilite port=height bundle=control
#pragma HLS INTERFACE s_axilite port=channels bundle=control
#pragma HLS INTERFACE s_axilite port=pool_size bundle=control
#pragma HLS INTERFACE m_axi depth=65536 port=image offset=slave bundle=input //gmem
#pragma HLS INTERFACE m_axi depth=65536 port=pooled_image offset=slave bundle=output //gmem
#pragma HLS PIPELINE

    int pooled_width = width / pool_size;
    int pooled_height = height / pool_size;

    for (int c = 0; c < channels; ++c) {
        for (int i = 0; i < pooled_height; ++i) {
            for (int j = 0; j < pooled_width; ++j) {
                unsigned char min_val = 255; // Assuming 8-bit unsigned char
                for (int m = 0; m < pool_size; ++m) {
                    for (int n = 0; n < pool_size; ++n) {
#pragma HLS UNROLL
                        int index = ((i * pool_size + m) * width + (j * pool_size + n)) * channels + c;
                        if (image[index] < min_val) {
                            min_val = image[index];
                        }
                    }
                }
                int pooled_index = (i * pooled_width + j) * channels + c;
                pooled_image[pooled_index] = min_val;
            }
        }
    }
}
