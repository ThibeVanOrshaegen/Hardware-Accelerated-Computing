#define STBI_NO_SIMD
#define STBI__X64_TARGET
#define STBI_NO_THREAD_LOCALS
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h"
#include <stdio.h>
#include <stdlib.h>
#include "stdbool.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "hls_top_function.h"

clock_t start, stop;
double cpu_time;


int main(int argc, char* argv[]) {
    if (argc < 2) {
        printf("Usage: %s <input_image_path> <output_image_path>\n", argv[0]);
        return 1;
    }

    const char* input_filename = argv[1];
    const char* output_filename = argv[2];

    // Load the input image
    int width, height, channels;
    unsigned char* img = stbi_load(input_filename, &width, &height, &channels, 0);
    if (img == NULL) {
        printf("Error in loading the image\n");
        return 1;
    }

    int pool_size = 2;
    int pooled_width = width / pool_size;
    int pooled_height = height / pool_size;
    int pooled_size = pooled_width * pooled_height * channels;

    unsigned char* pooled_image = (unsigned char*)malloc(pooled_size);
    if (pooled_image == NULL) {
        printf("Error in memory allocation\n");
        stbi_image_free(img);
        return 1;
    }

    start = clock();
    max_pooling(img, pooled_image, width, height, channels, pool_size);
    stop = clock();
    cpu_time = ((double)(stop - start)) / CLOCKS_PER_SEC;
    printf("Max pooling time taken: %f\n", cpu_time);

    // Saving the output image with the specified filename
    if (!stbi_write_png(output_filename, pooled_width, pooled_height, channels, pooled_image, 0)) {
        printf("Error in saving the output image\n");
        free(pooled_image);
        stbi_image_free(img);
        return 1;
    }

    // Free memory
    stbi_image_free(img);
    free(pooled_image);

    return 0;
}
